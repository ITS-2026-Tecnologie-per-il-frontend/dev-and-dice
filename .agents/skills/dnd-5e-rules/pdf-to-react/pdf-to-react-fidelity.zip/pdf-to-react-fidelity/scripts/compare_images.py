#!/usr/bin/env python3
"""Create a transparent overlay and absolute-difference image for two same-sized renders."""
import argparse
from pathlib import Path
from PIL import Image, ImageChops, ImageStat


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('reference', type=Path)
    ap.add_argument('rendered', type=Path)
    ap.add_argument('--out', type=Path, default=Path('diff.png'))
    args = ap.parse_args()
    a = Image.open(args.reference).convert('RGB')
    b = Image.open(args.rendered).convert('RGB')
    if a.size != b.size:
        raise SystemExit(f'Image sizes differ: reference={a.size}, rendered={b.size}. Set identical viewport & scale.')
    diff = ImageChops.difference(a, b)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    diff.save(args.out)
    overlay = args.out.with_name(args.out.stem + '-overlay.png')
    Image.blend(a, b, 0.5).save(overlay)
    avg = sum(ImageStat.Stat(diff).mean) / 3
    print(f'Average absolute channel difference (0..255): {avg:.2f}')
    print(f'Difference: {args.out}\nOverlay: {overlay}')


if __name__ == '__main__':
    main()
