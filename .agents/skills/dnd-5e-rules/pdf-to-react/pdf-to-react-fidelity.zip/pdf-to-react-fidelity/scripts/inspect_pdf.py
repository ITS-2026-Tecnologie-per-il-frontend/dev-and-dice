#!/usr/bin/env python3
"""Create visual and extraction baselines for PDF-to-React reconstruction."""
import argparse
import json
from pathlib import Path

import pymupdf


def rect_coords(rect):
    return [round(float(n), 3) for n in rect]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('pdf', type=Path)
    ap.add_argument('--out', type=Path, default=Path('.pdf-fidelity'))
    ap.add_argument('--dpi', type=int, default=160)
    ap.add_argument('--max-pages', type=int, default=0, help='0 means all pages')
    args = ap.parse_args()
    if args.dpi < 36 or args.dpi > 600:
        ap.error('--dpi should be between 36 and 600')
    args.out.mkdir(parents=True, exist_ok=True)
    pages_out = args.out / 'pages'
    assets_out = args.out / 'images'
    pages_out.mkdir(exist_ok=True)
    assets_out.mkdir(exist_ok=True)
    doc = pymupdf.open(str(args.pdf))
    if doc.needs_pass:
        raise SystemExit('Encrypted PDF: supply an unlocked source file')
    result = {'source': str(args.pdf.resolve()), 'dpi': args.dpi, 'page_count': len(doc), 'pages': []}
    limit = len(doc) if args.max_pages == 0 else min(len(doc), args.max_pages)
    for index in range(limit):
        page = doc[index]
        ident = f'page-{index+1:03d}'
        png_path = pages_out / f'{ident}.png'
        svg_path = pages_out / f'{ident}-reference.svg'
        page.get_pixmap(dpi=args.dpi, alpha=False).save(str(png_path))
        # Fidelity reference only: do not use this whole-page SVG as the final webpage.
        svg_path.write_text(page.get_svg_image(text_as_path=False), encoding='utf-8')
        spans = []
        imgs = []
        text_dict = page.get_text('dict')
        for block in text_dict.get('blocks', []):
            if block['type'] == 0:
                for line in block.get('lines', []):
                    for span in line.get('spans', []):
                        spans.append({
                            'text': span.get('text', ''), 'bbox': rect_coords(span['bbox']),
                            'font': span.get('font'), 'size': span.get('size'),
                            'color_int': span.get('color'), 'flags': span.get('flags'),
                        })
            elif block['type'] == 1 and block.get('image'):
                extension = block.get('ext', 'png')
                if not extension.isalnum():
                    extension = 'bin'
                fname = f'{ident}-image-{len(imgs)+1:03d}.{extension}'
                (assets_out / fname).write_bytes(block['image'])
                imgs.append({'file': f'images/{fname}', 'bbox': rect_coords(block['bbox'])})
        drawings = page.get_drawings()
        summary = {
            'index': index+1, 'width_pt': round(page.rect.width, 3),
            'height_pt': round(page.rect.height, 3),
            'preview': f'pages/{ident}.png', 'reference_svg': f'pages/{ident}-reference.svg',
            'text_spans': spans, 'images': imgs, 'vector_path_count': len(drawings),
            'vector_bboxes': [rect_coords(d['rect']) for d in drawings[:500]],
        }
        result['pages'].append(summary)
        print(f'{ident}: {page.rect.width:.1f} x {page.rect.height:.1f} pt, '
              f'{len(spans)} spans, {len(drawings)} vector paths, {len(imgs)} raster images')
    (args.out / 'manifest.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    print(f'Manifest: {args.out / "manifest.json"}')


if __name__ == '__main__':
    main()
