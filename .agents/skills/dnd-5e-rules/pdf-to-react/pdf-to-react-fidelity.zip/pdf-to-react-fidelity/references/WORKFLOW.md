# Local setup and visual review

## Install Codex skill globally (Windows PowerShell)

Extract the ZIP. In the directory containing `pdf-to-react-fidelity`:

```powershell
New-Item -ItemType Directory -Force "$HOME\.agents\skills" | Out-Null
Copy-Item -Recurse -Force ".\pdf-to-react-fidelity" "$HOME\.agents\skills\"
py -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r .\pdf-to-react-fidelity\requirements.txt
```

For **project-local installation**, put the folder at `<your-repository>/.agents/skills/pdf-to-react-fidelity` instead. The Python environment can live elsewhere; the skill does not require global Python packages. Reopen VS Code/Codex if not detected.

## Arch Linux

```bash
mkdir -p ~/.agents/skills
cp -r pdf-to-react-fidelity ~/.agents/skills/
python -m venv .venv
.venv/bin/python -m pip install -r pdf-to-react-fidelity/requirements.txt
```

## Inspect

```powershell
.\.venv\Scripts\python.exe .\pdf-to-react-fidelity\scripts\inspect_pdf.py ".\MANUALI\documento.pdf" --out .pdf-fidelity --dpi 160 --max-pages 3
```

The provided `--max-pages` is for a fast trial. Drop it for all pages. For large books, limit scope and iterate. In Arch, replace executable with `.venv/bin/python` and adjust slashes.

## Sample Codex prompt

> Use $pdf-to-react-fidelity to reproduce pages 1–3 of `MANUALI/documento.pdf` in my current Vite + React project. Match physical page proportions and ornament details. Extract or reconstruct decorative linework as reusable editable SVG React components. Keep paragraphs as selectable HTML text and shared styles as CSS variables. Render browser screenshots matching the PDF previews and iterate until the major discrepancies are fixed. Document areas that are raster-only, licensing constraints and any deviations. Do not redesign the page.

## Visual inspection checklist

- Exact page dimensions / crop box / bleed assumptions
- Margins, baseline grid and paragraph widths
- Font family, weight, ligatures and line wrap
- Decorative flourish placement, scales, stroke profiles
- Gradients, overlays, transparency and image masks
- Repeated layout ornaments built from one component
- Correct z-index and clipping at SVG/HTML boundaries
- All body text still selectable, semantic and accessible
- Narrow viewport readable or intentionally horizontally scrollable
- Original screenshot, React screenshot, diff/overlay retained

## Interpretation

A tiny pixel-difference score is not guaranteed across PDF/browser rasterizers because fonts and antialiasing differ. Prioritize document accuracy and visual geometry over chasing antialiasing noise.
